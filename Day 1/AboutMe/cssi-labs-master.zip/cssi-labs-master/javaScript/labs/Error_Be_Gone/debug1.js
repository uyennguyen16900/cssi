// Copyright 2018 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

const addFive = (number) => {
  return number + "5";
};

const checkNumis6 = (myNumber) => {
  if(number == 6);
  {
    return "Number is 6";
  }
  else{
    return "Number is not 6";
  }
};

const subTen = (number) => {
  return
  number - 10;
};

// Test Functions

// Expected output: 10
console.log(addFive(5));

// Expected output: 5
console.log(subTen(15));

// Expected output: Number is not 6
console.log(checkNumis6(7));
